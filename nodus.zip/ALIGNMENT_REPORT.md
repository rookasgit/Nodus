# Terminology Alignment Report

After reviewing the recent stylistic updates in `README.md`, `MANIFESTO.md`, and `ARCHITECTURE.md`, I performed an audit of the codebase (primarily focusing on `src/App.tsx`, `components/`, and state variables) to see if the UI and code terminology match the new "portfolio" vocabulary.

Here are the discrepancies and areas that need alignment to ensure the application actually delivers on the high-end design terms promised in the documentation.

---

### Discrepancy 1: "Shadow Council / Black Swan" vs. Current Code
**Documentation:** Uses "Shadow Council / Black Swan", "Timeline Branching", "Wargame the impossible."
**Codebase:**
* The modal is called `BranchModal` (`src/components/BranchModal.tsx`).
* UI buttons currently say `Branch Scenario`.
* Internal state variables use `isBranchModalOpen`, `branchConcept`.
* The system injects a message labeled `SCENARIO PIVOT / BLACK SWAN EVENT: ...`.
**Recommendation:** 
Rename the UI button from "Branch Scenario" to **"Inject Black Swan"** or **"Fork to Shadow Council"**. The internal component `BranchModal` is technically fine, but updating the user-facing text is critical for portfolio immersion.

### Discrepancy 2: "Insight Harvester" vs. Current Code
**Documentation:** Uses "Insight Harvester".
**Codebase:**
* Uses `isExtractMode`, `showExtractTooltip`, `selectedExtractText`, `handleExtractToBuffer`.
* The tooltip UI says `[Extract to Canvas]`.
* The button says `Toggle Extract Mode`.
**Recommendation:**
Rename the UI elements. The tooltip should say **"Harvest Insight"** and the mode toggle should be **"Insight Harvester Mode"** or **"Enable Harvester"**. The internal function names like `handleExtractTextToCanvas` are acceptable, but the UI labels need to reflect the branding.

### Discrepancy 3: "Grounded Ledger" vs. Current Code
**Documentation:** Promotes the "Grounded Ledger".
**Codebase:**
* The background verification agent relies on `You are a rigorous fact-checker...` prompts.
* Internal vars are called `factCheckerResults`, `factCheckFeedback`.
* The UI likely still says "Fact-Checking" or "Sources" based on `[POSTER_TITLE]` logic.
**Recommendation:**
Change the background prompt instructions from "rigorous fact-checker" to "Grounded Ledger Auditor". Any UI component rendering citations should label them as the **"Grounded Ledger"** instead of standard "Sources".

### Discrepancy 4: "Synthesis Topology" vs. Current Code
**Documentation:** Replaces "Summary/Summarizing" with "Synthesis Topology" and "Cognitive Assembly Engine".
**Codebase:**
* Internally, the app hits the mark with `Synthesizer`, `radar_data`, `heatmap_data`, and `whitepaper_markdown`.
* However, UI renders strings like: `## [ EXECUTIVE SYNTHESIS ]` and `SYSTEM SYNTHESIS: [POSTER_TITLE]`.
* Fallback strings yield things like `Text to Check (Synthesis/Conclusion)`.
**Recommendation:**
Update markdown generator templates to output `## [ SYNTHESIS TOPOLOGY ]` instead of Executive Synthesis. 

### Discrepancy 5: "Epistemological Friction" & "Dialectic Dismantling" vs. Current Code
**Documentation:** Replaces "Brainstorming" and "AI Arguing" with these terms.
**Codebase:**
* The code injects: `STRATEGY: AMPLIFY CONFLICT. Focus strictly on where the agents disagree.`
* Uses prompts like: `Write a concise rebuttal directly addressing that specific agent by name. Defend your worldview against theirs. Do not summarize the arguments; attack the intellectual friction point directly...`
* Uses: `Strategic Dialectic Engine`.
**Verdict:**
The code is actually *very well aligned* here. The system instructions explicitly enforce friction and use "Dialectical & Rhetorical Style" parameters. No major UI updates are needed for this specific pillar, as the structure is naturally enforcing it.

---

### Next Steps Action Plan (Would you like me to execute this?)
1. Find and replace `Extract to Canvas` -> `Harvest Insight` inside the React floating tooltip component.
2. Replace `Branch Scenario` -> `Inject Black Swan` in the timeline actions.
3. Update the Markdown String Builder for the Synthesizer to output `# [ SYNTHESIS TOPOLOGY ]`.
4. Update the Fact-checking prompts to refer to the **Grounded Ledger** for stylistic consistency if they ever leak into the UI.
